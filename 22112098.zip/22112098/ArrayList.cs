﻿using System.Collections.Generic;

namespace Schd
{
    internal class ArrayList<T> : List<Process>
    {
        public ArrayList(IEnumerable<Process> collection) : base(collection)
        {
        }
    }
}